<?php
session_start();
if (!isset($_SESSION['level']) || $_SESSION['level'] != 'admin') {
    echo "<script>alert('Silakan login terlebih dahulu!'); window.location='../../login.php';</script>";
    exit();
}
include '../../koneksi.php';
include '../components/header.php';
include '../components/sidebar.php';
?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
    <!-- Judul dan Tombol Tambah di Sebelah Kiri -->
    <div class="pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h3 fw-bold mb-3" style="color: #db2777;">Kelola Data Petugas</h1>
        <a href="tambah_petugas.php" class="btn btn-primary text-white" style="background-color: #db2777; border-color: #db2777;">
            <i class="bi bi-plus-lg me-1"></i> Tambah Petugas
        </a>
    </div>

    <!-- Tabel Daftar Petugas -->
    <div class="card border-0 shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Username</th>
                            <th>Nama Petugas</th>
                            <th>Level</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        $data_petugas = mysqli_query($koneksi, "SELECT * FROM petugas ORDER BY id_petugas DESC");
                        while ($row = mysqli_fetch_assoc($data_petugas)) {
                        ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td class="fw-semibold"><?php echo htmlspecialchars($row['username']); ?></td>
                                <td><?php echo htmlspecialchars($row['nama_petugas']); ?></td>
                                <td>
                                    <span class="badge <?php echo ($row['level'] == 'admin') ? 'bg-danger' : 'bg-info text-dark'; ?>">
                                        <?php echo ucfirst($row['level']); ?>
                                    </span>
                                </td>
                                <td class="text-center">
                                    <a href="edit_petugas.php?id=<?php echo $row['id_petugas']; ?>" class="btn btn-sm btn-warning text-white px-2 py-1"><i class="bi bi-pencil-square"></i></a>
                                    <a href="hapus_petugas.php?id=<?php echo $row['id_petugas']; ?>" class="btn btn-sm btn-danger px-2 py-1" onclick="return confirm('Yakin ingin menghapus petugas ini?')"><i class="bi bi-trash"></i></a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<?php include '../components/footer.php'; ?>